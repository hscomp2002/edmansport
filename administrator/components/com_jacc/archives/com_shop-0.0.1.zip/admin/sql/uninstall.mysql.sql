DROP TABLE IF EXISTS #__edman_factor;
DROP TABLE IF EXISTS #__edman_factor_det;
DROP TABLE IF EXISTS #__edman_gallery;
DROP TABLE IF EXISTS #__edman_kala;
DROP TABLE IF EXISTS #__edman_sabad;
