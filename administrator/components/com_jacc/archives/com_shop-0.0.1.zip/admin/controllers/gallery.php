<?php
/**
* @version		$Id:default.php 1 2015-03-23 05:41:10Z  $
* @package		Shop
* @subpackage 	Controllers
* @copyright	Copyright (C) 2015, . All rights reserved.
* @license 		
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controlleradmin');
jimport('joomla.application.component.controllerform');

/**
 * ShopGallery Controller
 *
 * @package    Shop
 * @subpackage Controllers
 */
class ShopControllerGallery extends JControllerForm
{
	public function __construct($config = array())
	{
	
		$this->view_item = 'gallery';
		$this->view_list = 'galleries';
		parent::__construct($config);
	}	
	
	/**
	 * Proxy for getModel.
	 *
	 * @param   string	$name	The name of the model.
	 * @param   string	$prefix	The prefix for the PHP class name.
	 *
	 * @return  JModel
	 * @since   1.6
	 */
	public function getModel($name = 'Gallery', $prefix = 'ShopModel', $config = array('ignore_request' => false))
	{
		$model = parent::getModel($name, $prefix, $config);
	
		return $model;
	}	
}// class
?>