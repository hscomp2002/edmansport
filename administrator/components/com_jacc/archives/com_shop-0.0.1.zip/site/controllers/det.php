 <?php
/**
* @version		$Id$ $Revision$ $Date$ $Author$ $
* @package		Shop
* @subpackage 	Controllers
* @copyright	Copyright (C) 2015, . All rights reserved.
* @license #
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * ShopDet Controller
 *
 * @package    Shop
 * @subpackage Controllers
 */
class ShopControllerDet extends JControllerLegacy
{
		
}// class
?>